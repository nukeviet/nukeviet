<?php

/**
 * NukeViet Content Management System
 * @version 4.x
 * @author VINADES.,JSC <contact@vinades.vn>
 * @copyright (C) 2009-2021 VINADES.,JSC. All rights reserved
 * @license GNU/GPL version 2 or any later version
 * @see https://github.com/nukeviet The NukeViet CMS GitHub project
 */

if (!defined('NV_MAINFILE')) {
    exit('Stop!!!');
}

define('NV_MOD_TABLE', $db_config['prefix'] . '_zalo');
$zalo = new NukeViet\Zalo\Zalo($global_config);

$module_configs = [];
$event_actions = [];
$sql = "SELECT * FROM " . NV_MOD_TABLE . "_settings";
$result = $db->query($sql);
while ($row = $result->fetch()) {
    if ($row['type'] == 'action') {
        $event_actions[$row['skey']] = json_decode($row['svalue'], true);
    } else {
        !isset($module_configs[$row['type']]) && $module_configs[$row['type']] = [];
        $module_configs[$row['type']][$row['skey']] = $row['svalue'];
    }
}

/**
 * parse_phone()
 * 
 * @param mixed $number 
 * @return array 
 */
function parse_phone($number)
{
    include NV_ROOTDIR . '/' . NV_DATADIR . '/callingcodes.php';

    $number = (string) $number;
    $number = preg_replace('/[^0-9]+/', '', $number);
    if (str_starts_with($number, '0')) {
        $number = '84' . substr($number, 1);
    }
    $digist6 = (int) substr($number, 0, 6);
    if (isset($callingcodes2[$digist6])) {
        return [$callingcodes2[$digist6][0], substr($number, 6)];
    }

    $digist4 = (int) substr($number, 0, 4);
    if (isset($callingcodes2[$digist4])) {
        return [$callingcodes2[$digist4][0], substr($number, 4)];
    }

    $digist3 = (int) substr($number, 0, 3);
    if (isset($callingcodes2[$digist3])) {
        return [$callingcodes2[$digist3][0], substr($number, 3)];
    }

    $digist2 = (int) substr($number, 0, 2);
    if (isset($callingcodes2[$digist2])) {
        return [$callingcodes2[$digist2][0], substr($number, 2)];
    }

    return ['', $number];
}

/**
 * get_province_id()
 * 
 * @param mixed $name 
 * @return mixed 
 */
function get_province_id($name)
{
    include NV_ROOTDIR . '/' . NV_DATADIR . '/vnsubdivisions.php';

    foreach ($provinces as $id => $province_name) {
        foreach ($province_name as $_name) {
            if (str_ends_with($_name, $name)) {
                return $id;
            }
        }
    }

    return '';
}

/**
 * get_district_id()
 * 
 * @param mixed $city_id 
 * @param mixed $district 
 * @return mixed 
 */
function get_district_id($city_id, $district)
{
    include NV_ROOTDIR . '/' . NV_DATADIR . '/vnsubdivisions.php';

    foreach ($districts[$city_id] as $id => $district_name) {
        foreach ($district_name as $_district) {
            if (str_ends_with($_district, $district)) {
                return $id;
            }
        }
    }

    return '';
}

/**
 * webhook_handle()
 * 
 * @param mixed $data 
 * @throws PDOException 
 */
function webhook_handle($data)
{
    global $db, $global_config;

    if (!empty($data['message']['msg_id'])) {
        $sth = $db->prepare('INSERT IGNORE INTO ' . NV_MOD_TABLE . "_conversation 
        (message_id, user_id, src, time, type, message, links, thumb, url, description, location, note) VALUES 
        (:message_id, :user_id, :src, :time, :type, :message, :links, :thumb, :url, :description, :location, '')");

        if ($data['sender']['id'] != $global_config['zaloOfficialAccountID']) {
            $src = 1;
            $user_id = $data['sender']['id'];
        } else {
            $src = 0;
            $user_id = $data['recipient']['id'];
        }

        $contents = [
            'message_id' => $data['message']['msg_id'],
            'time' => $data['timestamp'],
            'type' => 'nosupport',
            'message' => !empty($data['message']['text']) ? $data['message']['text'] : '',
            'links' => '',
            'thumb' => '',
            'url' => '',
            'description' => '',
            'location' => ''
        ];

        switch ($data['event_name']) {
            case 'user_send_location':
                $contents['type'] = 'location';
                $contents['location'] = '{"longitude":"' . $data['message']['attachments'][0]['payload']['coordinates']['longitude'] . '","latitude":"' . $data['message']['attachments'][0]['payload']['coordinates']['latitude'] . '"}';
                break;
            case 'user_send_image':
            case 'oa_send_image':
                $contents['type'] = 'photo';
                $contents['thumb'] = $data['message']['attachments'][0]['payload']['thumbnail'];
                $contents['url'] = $data['message']['attachments'][0]['payload']['url'];
                break;
            case 'user_send_link':
                $contents['type'] = 'link';
                $contents['links'] = '[{"title":"","url":"' . $data['message']['attachments'][0]['payload']['url'] . '","thumb":"' . $data['message']['attachments'][0]['payload']['thumbnail'] . '","description":"' . $data['message']['attachments'][0]['payload']['description'] . '"}]';
                break;
            case 'user_send_text':
            case 'oa_send_text':
                $contents['type'] = 'text';
                break;
            case 'user_send_sticker':
                $contents['type'] = 'sticker';
                $contents['url'] = $data['message']['attachments'][0]['payload']['url'];
                break;
            case 'user_send_gif':
            case 'oa_send_gif':
                $contents['type'] = 'gif';
                $contents['thumb'] = $data['message']['attachments'][0]['payload']['thumbnail'];
                $contents['url'] = $data['message']['attachments'][0]['payload']['url'];
                break;
            case 'user_send_audio':
                $contents['type'] = 'voice';
                $contents['url'] = $data['message']['attachments'][0]['payload']['url'];
                break;
            case 'user_send_video':
                $contents['type'] = 'video';
                $contents['thumb'] = $data['message']['attachments'][0]['payload']['thumbnail'];
                $contents['description'] = $data['message']['attachments'][0]['payload']['description'];
                $contents['url'] = $data['message']['attachments'][0]['payload']['url'];
                break;
            case 'user_send_file':
            case 'oa_send_file':
                $contents['type'] = 'file';
                $contents['description'] = $data['message']['attachments'][0]['payload']['name'];
                $contents['url'] = $data['message']['attachments'][0]['payload']['url'];
                break;
            case 'oa_send_list':
                $links = [];
                foreach ($data['message']['attachments'] as $link) {
                    $links[] = $link['payload'];
                }
                $contents['type'] = 'links';
                $contents['links'] = json_encode($links);
                break;
        }

        $sth->bindValue(':message_id', $contents['message_id'], PDO::PARAM_STR);
        $sth->bindParam(':user_id', $user_id, PDO::PARAM_STR);
        $sth->bindParam(':src', $src, PDO::PARAM_INT);
        $sth->bindParam(':time', $contents['time'], PDO::PARAM_INT);
        $sth->bindParam(':type', $contents['type'], PDO::PARAM_STR);
        $sth->bindParam(':message', $contents['message'], PDO::PARAM_STR);
        $sth->bindParam(':links', $contents['links'], PDO::PARAM_STR);
        $sth->bindParam(':thumb', $contents['thumb'], PDO::PARAM_STR);
        $sth->bindParam(':url', $contents['url'], PDO::PARAM_STR);
        $sth->bindParam(':description', $contents['description'], PDO::PARAM_STR);
        $sth->bindParam(':location', $contents['location'], PDO::PARAM_STR);
        $sth->execute();
    } elseif ($data['event_name'] == 'follow' or $data['event_name'] == 'unfollow') {
        $isfollow = $data['event_name'] == 'follow' ? 1 : 0;

        $offset = $db->query('SELECT MAX(weight) FROM ' . NV_MOD_TABLE . '_followers')->fetchColumn();
        $offset++;

        $sth = $db->prepare("INSERT INTO " . NV_MOD_TABLE . "_followers (user_id, app_id, user_id_by_app, tags_info, notes_info, isfollow, weight, updatetime) VALUES 
        (:user_id, :app_id, :user_id_by_app, '', '', :isfollow, :weight, :updatetime) ON DUPLICATE KEY UPDATE app_id=VALUES(app_id), isfollow=VALUES(isfollow), updatetime=VALUES(updatetime)");

        $sth->bindValue(':user_id', $data['follower']['id'], PDO::PARAM_STR);
        $sth->bindValue(':app_id', $data['app_id'], PDO::PARAM_STR);
        $sth->bindValue(':user_id_by_app', $data['user_id_by_app'], PDO::PARAM_STR);
        $sth->bindValue(':isfollow', $isfollow, PDO::PARAM_INT);
        $sth->bindValue(':weight', $offset, PDO::PARAM_INT);
        $sth->bindValue(':updatetime', $data['timestamp'], PDO::PARAM_INT);
        $sth->execute();
    } elseif ($data['event_name'] == 'user_submit_info') {
        $phone_code = $phone_number = '';
        if (!empty($data['info']['phone'])) {
            list($phone_code, $phone_number) = parse_phone($data['info']['phone']);
        }
        $address = !empty($data['info']['address']) ? $data['info']['address'] : '';
        if (!empty($data['info']['ward'])) {
            !empty($address) && $address .= ', ';
            $address .= $data['info']['ward'];
        }
        $city_id = !empty($data['info']['city']) ? get_province_id($data['info']['city']) : '';
        $district_id = (!empty($city_id) and !empty($data['info']['district'])) ? get_district_id($city_id, $data['info']['district']) : '';
        $name = !empty($data['info']['name']) ? $data['info']['name'] : '';
        $offset = $db->query('SELECT MAX(weight) FROM ' . NV_MOD_TABLE . '_followers')->fetchColumn();
        $offset++;

        $sth = $db->prepare("INSERT INTO " . NV_MOD_TABLE . "_followers (user_id, app_id, user_id_by_app, tags_info, notes_info, weight, name, phone_code, phone_number, address, city_id, district_id, is_sync, updatetime) VALUES 
        (:user_id, :app_id, :user_id_by_app, '', '', :weight, :name, :phone_code, :phone_number, :address, :city_id, :district_id, 0, :updatetime) ON DUPLICATE KEY UPDATE 
        app_id=VALUES(app_id), name=VALUES(name), phone_code=VALUES(phone_code), phone_number=VALUES(phone_number), address=VALUES(address), city_id=VALUES(city_id), district_id=VALUES(district_id), updatetime=VALUES(updatetime)");
        $sth->bindValue(':user_id', $data['sender']['id'], PDO::PARAM_STR);
        $sth->bindValue(':app_id', $data['app_id'], PDO::PARAM_STR);
        $sth->bindValue(':user_id_by_app', $data['user_id_by_app'], PDO::PARAM_STR);
        $sth->bindValue(':weight', $offset, PDO::PARAM_INT);
        $sth->bindValue(':name', $name, PDO::PARAM_STR);
        $sth->bindValue(':phone_code', $phone_code, PDO::PARAM_STR);
        $sth->bindValue(':phone_number', $phone_number, PDO::PARAM_STR);
        $sth->bindValue(':address', $address, PDO::PARAM_STR);
        $sth->bindValue(':city_id', $city_id, PDO::PARAM_STR);
        $sth->bindValue(':district_id', $district_id, PDO::PARAM_STR);
        $sth->bindValue(':updatetime', $data['timestamp'], PDO::PARAM_INT);
        $sth->execute();
    }
}

$webhook_data['app_id'] = preg_replace('/[^0-9]+/', '', $webhook_data['app_id']);
$webhook_data['message']['msg_id'] = preg_replace('/[^a-zA-Z0-9\_]+/', '', $webhook_data['message']['msg_id']);
!empty($webhook_data['message']['text']) && $webhook_data['message']['text'] = trim(strip_tags($webhook_data['message']['text'], '<br>'));
!empty($webhook_data['message']['attachments'][0]['payload']['id']) && $webhook_data['message']['attachments'][0]['payload']['id'] = preg_replace('/[^a-zA-Z0-9\_]+/', '', $webhook_data['message']['attachments'][0]['payload']['id']);
if (!empty($webhook_data['message']['attachments'][0]['payload']['thumbnail'])) {
    if (!nv_is_url($webhook_data['message']['attachments'][0]['payload']['thumbnail'])) {
        $webhook_data['message']['attachments'][0]['payload']['thumbnail'] = '';
    }
}
if (!empty($webhook_data['message']['attachments'][0]['payload']['url'])) {
    if (!nv_is_url($webhook_data['message']['attachments'][0]['payload']['url'])) {
        $webhook_data['message']['attachments'][0]['payload']['url'] = '';
    }
}
!empty($webhook_data['message']['attachments'][0]['payload']['coordinates']['latitude']) && $webhook_data['message']['attachments'][0]['payload']['coordinates']['latitude'] = preg_replace('/[^0-9\.\+\-]+/', '', $webhook_data['message']['attachments'][0]['payload']['coordinates']['latitude']);
!empty($webhook_data['message']['attachments'][0]['payload']['coordinates']['longitude']) && $webhook_data['message']['attachments'][0]['payload']['coordinates']['longitude'] = preg_replace('/[^0-9\.\+\-]+/', '', $webhook_data['message']['attachments'][0]['payload']['coordinates']['longitude']);
!empty($webhook_data['message']['attachments'][0]['payload']['size']) && $webhook_data['message']['attachments'][0]['payload']['size'] = preg_replace('/[^0-9]+/', '', $webhook_data['message']['attachments'][0]['payload']['size']);
!empty($webhook_data['message']['attachments'][0]['payload']['name']) && $webhook_data['message']['attachments'][0]['payload']['name'] = trim(strip_tags($webhook_data['message']['attachments'][0]['payload']['name']));
!empty($webhook_data['message']['attachments'][0]['payload']['description']) && $webhook_data['message']['attachments'][0]['payload']['description'] = trim(strip_tags($webhook_data['message']['attachments'][0]['payload']['description'], '<br>'));
!empty($webhook_data['info']['address']) && $webhook_data['info']['address'] = trim(strip_tags($webhook_data['info']['address'], '<br>'));
!empty($webhook_data['info']['phone']) && $webhook_data['info']['phone'] = preg_replace('/[^0-9]+/', '', $webhook_data['info']['phone']);
!empty($webhook_data['info']['city']) && $webhook_data['info']['city'] = trim(strip_tags($webhook_data['info']['city']));
!empty($webhook_data['info']['district']) && $webhook_data['info']['district'] = trim(strip_tags($webhook_data['info']['district']));
!empty($webhook_data['info']['name']) && $webhook_data['info']['name'] = trim(strip_tags($webhook_data['info']['name']));
!empty($webhook_data['info']['ward']) && $webhook_data['info']['ward'] = trim(strip_tags($webhook_data['info']['ward']));

$webhook_data['sender']['id'] = preg_replace('/[^0-9]+/', '', $webhook_data['sender']['id']);
$webhook_data['user_id_by_app'] = preg_replace('/[^0-9]+/', '', $webhook_data['user_id_by_app']);
$webhook_data['timestamp'] = floor((int) $webhook_data['timestamp'] / 1000);

webhook_handle($webhook_data);
