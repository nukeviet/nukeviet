<?php

/**
 * NukeViet Content Management System
 * @version 4.x
 * @author VINADES.,JSC <contact@vinades.vn>
 * @copyright (C) 2009-2021 VINADES.,JSC. All rights reserved
 * @license GNU/GPL version 2 or any later version
 * @see https://github.com/nukeviet The NukeViet CMS GitHub project
 */

if (!defined('NV_IS_FILE_ZALO')) {
    exit('Stop!!!');
}

if (!$zalo->isValid()) {
    nv_redirect_location(NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&' . NV_NAME_VARIABLE . '=' . $module_name . '&' . NV_OP_VARIABLE . '=settings');
}

$events = [
    'user_send_location',
    'user_send_image',
    'user_send_link',
    'user_send_text',
    'user_send_sticker',
    'user_send_gif',
    'user_send_audio',
    'user_send_video',
    'user_send_file',
    'user_received_message',
    'user_seen_message',
    'user_submit_info',
    'follow',
    'unfollow',
    'add_user_to_tag',
    'shop_has_order',
    'oa_send_text',
    'oa_send_image',
    'oa_send_list',
    'oa_send_gif',
    'oa_send_file'
];

$actions = [
    'sent_text_message',
    'sent_image_message',
    'sent_file_message',
    'sent_textlist_message',
    'sent_btnlist_message'
];

if ($nv_Request->isset_request('save,action,parameter', 'post')) {
    $action = $nv_Request->get_typed_array('action', 'post', 'title', []);
    $parameter = $nv_Request->get_typed_array('parameter', 'post', 'title', []);

    webhook_actions_save($action, $parameter);

    nv_jsonOutput([
        'status' => 'success',
        'mess' => ''
    ]);

}

$event_actions = get_webhook_actions();

$xtpl = new XTemplate('chatbot.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file);

$xtpl->assign('LANG', $lang_module);
$xtpl->assign('GLANG', $lang_global);
$xtpl->assign('DATA', $global_config);
$xtpl->assign('PAGE_LINK', NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=' . $op);

foreach ($events as $event) {
    $xtpl->assign('EVENT', [
        'key' => $event,
        'name' => $lang_module[$event],
        'action' => !empty($event_actions[$event][0]) ? $event_actions[$event][0] : '',
        'parameter' => !empty($event_actions[$event][1]) ? $event_actions[$event][1] : ''
    ]);

    foreach ($actions as $action) {
        switch ($action) {
            case 'sent_text_message':
                $url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=templates&amp;type=plaintext&amp;popup=1&amp;parameter=parameter_' . $event;
                $view_url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=templates&amp;preview=1&amp;id=';
                break;
            case 'sent_image_message':
                $url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=upload&amp;type=image&amp;popup=1&amp;idfield=parameter_' . $event;
                $view_url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=upload&amp;preview=1&amp;id=';
                break;
            case 'sent_file_message':
                $url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=upload&amp;type=file&amp;popup=1&amp;idfield=parameter_' . $event;
                $view_url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=upload&amp;preview=1&amp;id=';
                break;
            case 'sent_textlist_message':
                $url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=templates&amp;type=textlist&amp;popup=1&amp;idfield=parameter_' . $event;
                $view_url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=templates&amp;preview=1&amp;id=';
                break;
            case 'sent_btnlist_message':
                $url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=templates&amp;type=btnlist&amp;popup=1&amp;idfield=parameter_' . $event;
                $view_url = NV_BASE_ADMINURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module_name . '&amp;' . NV_OP_VARIABLE . '=templates&amp;preview=1&amp;id=';
                break;
        }

        $xtpl->assign('ACTION', [
            'key' => $action,
            'name' => $lang_module['action_' . $action],
            'sel' => (!empty($event_actions[$event][0]) and $action == $event_actions[$event][0]) ? ' selected="selected"' : '',
            'url' => $url,
            'view_url' => $view_url
        ]);
        $xtpl->parse('main.event.action');
    }
    $xtpl->parse('main.event');
}
$xtpl->parse('main');
$contents = $xtpl->text('main');

$page_title = $lang_module['chatbot'];

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
