<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @copyright 2009
 * @createdate 12/31/2009 0:51
 */

if ( ! defined( 'NV_AUTOUPDATE' ) ) die( 'Stop!!!' );

// Set update info with file structure to update
$update_info = array( 
    'version' => array( 
    'from' => '3.0.13', 'to' => '3.1.00' 
) 
);

$add_files = array( 
    'testabc.php','thaotesst'
);

$edit_files = array( 
    'index.php', //
	'mainfile.php', //
	'includes/bots.php', //
	'includes/constants.php', //
	'includes/footer.php', //
	'includes/functions.php' 
);

$delete_files = array( 
    'f.php' 
);

function nv_func_update_data ( )
{
    return true;
}

?>